To run type

npm install
npm start

import React, { Component } from 'react';
import Track from './Track';

class App extends Component {
  render() {
    return (
      <div>
        <Track />
      </div>
    );
  }
}

export default App;
